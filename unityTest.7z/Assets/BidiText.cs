﻿using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Text)), ExecuteInEditMode]
public class BidiText : MonoBehaviour
{
    [TextArea(5, 10), SerializeField]
    private string _value = string.Empty;

    private Text _text;
    private string _lastTextValue = null;

    public string Value => _value;

    public void SetText(string value)
    {
        _value = value;
        Update();
    }

    private void OnEnable()
    {
        _lastTextValue = null;
    }

    private void Update()
    {
        if (_lastTextValue != _value)
        {
            if (_text == null)
            {
                _text = GetComponent<Text>();
            }
            _text.text = string.IsNullOrEmpty(_value) ? _value : new Bidi().Convert(_value);
            _lastTextValue = _value;
            _text.alignment = TextAnchor.UpperRight;
        }
    }
}
