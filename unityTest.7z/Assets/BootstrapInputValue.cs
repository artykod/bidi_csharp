﻿using UnityEngine;
using UnityEngine.UI;

public class BootstrapInputValue : MonoBehaviour
{
    [TextArea(5, 10)]
    public string value;

    private void OnEnable()
    {
        GetComponent<BidiInputField>().text = value;
        GetComponent<BidiInputField>().ActivateInputField();
    }
}
