﻿public class PrintWriter
{
    public void print(string s)
    {
        System.Console.Write(s);
    }

    public void println(string s)
    {
        System.Console.WriteLine(s);
    }

    public void println()
    {
        System.Console.WriteLine();
    }
}